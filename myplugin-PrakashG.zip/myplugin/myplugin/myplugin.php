<?php 
/* 
Plugin Name: Fetch posts to every posts & pages
Description: This plugin will allow to fetch any perticular posts (with their post id) under every pages and posts (except homepage, and defined page / post ids).
Version: 1.0
Author: Prakash G
*/
?>
<?php

//defines excerpt length 

function create_posts()
	{
		$mypluginremove = explode(",",get_option('exids'));
		$mycon = "";
		if (!in_array(get_the_ID(),$mypluginremove)) 
		{ 	
			$mycon ="<br><h2>".get_option('title')."</h2>";
		
		if(trim(get_option('posttypee'))=='recent')
			{
				$recentPosts = new WP_Query( array( 'posts_per_page' => get_option('ids') ) );
			}
		else
			{
				$recentPosts = new WP_Query( array( 'post__in' => explode(",",get_option('ids')),'ignore_sticky_posts'=>1 ) );
			}
		
			
			while ($recentPosts->have_posts()) : $recentPosts->the_post(); 
			$mycon .= "<div class=\"post\" id=\"post-".get_the_ID()."\"><h2><a href=\"".get_permalink()."\" rel=\"bookmark\" title=\"Permanent Link to ".get_the_title()."\">".get_the_title()."</a></h2><div class=\"entry\">".my_wp_trim_excerpt(get_the_content())."</div></div>";
			endwhile; 
			wp_reset_query();
		} 
		//echo "[".$mycon."]";
		//$mycon = "<br><p>This is sample posts</p>";
		return $mycon ;
	}


function my_wp_trim_excerpt($text) {

	
	$text = strip_shortcodes( $text );
	
    
    $allowed_tags = '<a><b><strong>'; 
    $text = strip_tags($text, $allowed_tags);
 
    $excerpt_word_count = get_option('exlen'); 
    $excerpt_length = apply_filters('excerpt_length', $excerpt_word_count);
 
    $words = preg_split("/[\n\r\t ]+/", $text, $excerpt_length + 1, PREG_SPLIT_NO_EMPTY);
	$linkmore = '... <a href="'.get_permalink().'" class="more-link">'.get_option('rmore').'</a>';
    if ( count($words) > $excerpt_length ) {
        array_pop($words);
        $text = implode(' ', $words);
        $text = $text.$linkmore;
    } else {
        $text = implode(' ', $words);
    }
	

return $text;
}

	
function mycontent_filter($content)
	{
		if (!is_front_page() and !is_home())
		{
			return $content.display_author_info().create_posts();
		}
		elseif (is_front_page() and !is_home() and get_option('ifstatichome')==1)
		{
			return $content.display_author_info().create_posts();
		}
		else
		{
			return $content;
		}
	}	

function mt_posts_request_filter( $input ) {
	
	if (is_home() && get_option('ifstaticblog')==1  && !is_front_page())
	{
		if (get_option('posttypee')=='recent')
		{
			$t = get_posts(array('numberposts'=>get_option('ids')));
			$input = array_merge($input,$t);
		}
		else
		{
			$mid=get_option('ids');
			$t = get_posts(array('include'=>$mid));
			$input = array_merge($input,$t);
		}
		
	}
	elseif (is_home() && get_option('ifblog')==1  && is_front_page())
	{
		$mid=get_option('ids');
		$t = get_posts(array('include'=>$mid));
		$input = array_merge($input,$t);
	}
	return $input;
	
}


add_action( 'pre_get_posts', 'mt_modify_query_insert_selected' );
function mt_modify_query_insert_selected( $query ) {
    if ( ! is_admin() && $query->is_main_query() && ! $query->get( 'cat' ) )
			{
				add_filter( 'the_posts', 'mt_posts_request_filter' );
			}
			else
			{
				remove_filter( 'the_posts', 'mt_posts_request_filter' );
			}
}




add_action( 'admin_init', 'register_mysettings' );	
function register_mysettings() {
	//register our settings
	register_setting( 'fetch-settings-group', 'ids' );
	register_setting( 'fetch-settings-group', 'exids' );
	register_setting( 'fetch-settings-group', 'title' );
	register_setting( 'fetch-settings-group', 'rmore' );
	register_setting( 'fetch-settings-group', 'exlen' );
	register_setting( 'fetch-settings-group', 'show_author' );
	register_setting( 'fetch-settings-group', 'show_comments' );
	register_setting( 'fetch-settings-group', 'posttypee' );
	register_setting( 'fetch-settings-group', 'ifstatichome' );
	register_setting( 'fetch-settings-group', 'ifstaticblog' );
	register_setting( 'fetch-settings-group', 'ifblog' );
}
	
	
add_filter('the_content', 'mycontent_filter',5);
add_action('admin_menu', 'my_plugin_menu');

/* Start --->  extra functionality added to show author info and enable comments on selected posts only */
function display_author_info()
{
	$author_info = "";
	$mypostauthor = explode(",",get_option('show_author'));
	global $post;
	if (in_array($post->ID,$mypostauthor)) 
	{
		
		$user_info = get_userdata($post->post_author);
		//$author_info = "<p><strong>Author:</strong> ".$user_info->display_name." <strong>Website:</strong> <a href='".$user_info->user_url."'> ".$user_info->user_url."</a> </p>";
		
		$author_info ="<form><fieldset>
    <legend>About Author:</legend>
    <strong>Name:</strong> ".$user_info->display_name."<br />
    <strong>Website:</strong> <a target='_blank' href='".$user_info->user_url."'> ".$user_info->user_url."</a><br />
    
  </fieldset></form>";
		
	}
	return $author_info;
}


add_filter( 'get_header', 'open_comments_for_my_post');
function open_comments_for_my_post()
{
		$mypostcomment = explode(",",get_option('show_comments'));
		global $post;
		if (in_array($post->ID,$mypostcomment)) 
		{
			$post->comment_status = "open";
		}
		else
		{
			$post->comment_status = "close";
		}
    //return $open;
	//return true;
}  

/* Ends --->  extra functionality added to show author info and enable comments on selected posts only */

function my_plugin_menu() {
	add_options_page('Fetch Plugin Options', 'Fetch Plugin', 'manage_options', 'fetch-plugin-options', 'my_plugin_options');
}

function my_plugin_options() {
	if (!current_user_can('manage_options'))  {
		wp_die( __('You do not have sufficient permissions to access this page.') );
	}
	?>
	<div class="wrap">
	<h2>Fetch Plugin Options:</h2>
	<p>On this page you can configure, which posts to fetch below every page and where not to fetch - PrakashG.</p>

<form method="post" action="options.php">
    <?php settings_fields( 'fetch-settings-group' ); ?>
    <?php //do_settings_fields( 'fetch-settings-group' ); ?>
	<?php
		if (get_option('exlen')<10)
		{
			update_option('exlen',10);
		}
	
	?>
	<script >
		jQuery(document).ready(function($) {
					if($('#postt_1').attr('checked'))
					{
							$('#postt').html("Post ids (which you want to fetch)");
					}
					else if($('#postt_2').attr('checked'))
					{
						$('#postt').html("No. of most recent posts to fetch");
					}
					$('#postt_1').click(function() {
						$('#postt').html("Post ids (which you want to fetch)");
					});
					
					$('#postt_2').click(function() {
						$('#postt').html("No. of most recent posts to fetch");
					});
					
					
				});
		
	</script>
    <table class="form-table">
		 <tr valign="top">
        <th scope="row">How you would like to fetch?</th>
        <td>
		<input id='postt_1'  type="radio" name="posttypee" value="selected" <?php if (get_option('posttypee')=='selected') {echo "checked='checked'";} ?> /> Fetch Selected posts by id given above
		<input id='postt_2'  type="radio" name="posttypee" value="recent" <?php if (get_option('posttypee')=='recent') {echo "checked='checked'";} ?> /> Fetch Below given numbers of most recent posts.
		
		</td>
        </tr>


	   <tr valign="top">
        <th scope="row" id='postt'>Post ids (which you want to fetch)</th>
        <td><input type="text" name="ids" value="<?php echo get_option('ids'); ?>" />  // enter comma seperated ids, e.g. 2,34,55</td>
        </tr>
         
       
         
        <tr valign="top">
        <th scope="row">post and page ids (where you do not want to fetch)</th>
        <td><input type="text" name="exids" value="<?php echo get_option('exids'); ?>" /> // enter comma seperated ids, e.g. 21,434,5 </td>
        </tr>
        
        <tr valign="top">
        <th scope="row">Title (e.g. "Related posts", "Recent News")</th>
        <td><input type="text" name="title" value="<?php echo get_option('title'); ?>" /></td>
        </tr>
		
		 <tr valign="top">
        <th scope="row">Read More Text</th>
        <td><input type="text" name="rmore" value="<?php echo get_option('rmore'); ?>" /></td>
        </tr>
		
		 <tr valign="top">
        <th scope="row">Description Length in words. (10 minimum)</th>
        <td><input type="text" name="exlen" value="<?php  echo get_option('exlen'); ?>" /></td>
        </tr>
		
		 <tr valign="top">
        <th colspan="2" scope="row"><h2>How to Display Fetched Post ?</h2></th>
        
        </tr>
		
		 <tr valign="top">
        <th scope="row">&nbsp;</th>
        <td><input type="checkbox" name="ifstatichome" value="1"<?php checked( 1 == get_option('ifstatichome')); ?> /> Display Posts on homepage when home page is set as static page ? 
		
		</td>
        </tr>
		
		 <tr valign="top">
        <th scope="row">&nbsp;</th>
        <td><input type="checkbox" name="ifstaticblog" value="1"<?php checked( 1 == get_option('ifstaticblog')); ?> /> Display posts below the posts list on blog page when homepage is set as static page ?
		
		</td>
        </tr>
		
		 <tr valign="top">
        <th scope="row">&nbsp;</th>
        <td><input type="checkbox" name="ifblog" value="1"<?php checked( 1 == get_option('ifblog')); ?> /> Display posts below the list of posts on homepage when it is not set as static page and listing most recent posts?
		
		</td>
        </tr>

		<tr valign="top">
        <th scope="row"><h2>Extra Options:</h2></th>
        <td> &nbsp; </td>
        </tr>
		
		<tr valign="top">
        <th scope="row">Insert Comma separated IDs to show author info : </th>
        <td><input type="text" name="show_author" value="<?php  echo get_option('show_author'); ?>" /> // Where you want to show author box with author name and website.
		</td> 
        </tr>
		
		<tr valign="top">
        <th scope="row">Insert Comma separated IDs to enable comments : </th>
        <td><input type="text" name="show_comments" value="<?php  echo get_option('show_comments'); ?>" />// Where you want to allow comments. This will only allow the comments on posts you will define here, all other post will have their own settings, so if other posts have comments enabled, you have to disable it manually.
		</td> 
        </tr>
		
		
    </table>
    
    <p class="submit">
    <input type="submit" class="button-primary" value="<?php _e('Save Changes') ?>" />
    </p>

</form>
</div>
	<?php
	
}



?>